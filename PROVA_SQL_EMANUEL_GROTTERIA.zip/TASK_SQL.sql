#TASK2 Descrivi la struttura delle tabelle che reputi utili e sufficienti a modellare lo scenario proposto tramite la sintassi DDL. 
#Implementa fisicamente le tabelle utilizzando il DBMS SQL Server(o altro).
#Ho creato un nuovo DB chiamandolo esame_sql per non avere problemi nell'inserimento della query, in quanto, giustamente, mi dava l'errore che, ad esemp. la tabella 
#prodotti è già esistente. Esiste già nell'ADV.

USE esame_sql;

#Creo Tabella 

CREATE TABLE Prodotti
	(ID_Prodotto INT AUTO_INCREMENT PRIMARY KEY
    , NomeProdotto VARCHAR(50)
    , PrezzoUnitario DECIMAL(7,2)
    , ID_Categoria INT
    );
    
    SELECT * FROM Prodotti;
    
CREATE TABLE Categoria
	(ID_Categoria INT AUTO_INCREMENT PRIMARY KEY
    , NomeCategoria VARCHAR(50)
    );
    
    SELECT * FROM Categoria;
    
CREATE TABLE Sales
	(ID_Sales INT AUTO_INCREMENT PRIMARY KEY
    , NumeroOrdine VARCHAR(10)
    , DataOrdine DATE
    , ID_Prodotto INT
    , ID_Paese INT
    , Quantita INT
    );
    
    SELECT * FROM Sales;
    
CREATE TABLE Paese
	(ID_Paese INT AUTO_INCREMENT PRIMARY KEY
    , NomePaese VARCHAR(50)
    , ID_Regione INT
    );
    
    SELECT * FROM Paese;
    
CREATE TABLE Regione
	(ID_Regione INT AUTO_INCREMENT PRIMARY KEY
    , NomeRegione VARCHAR(50)
    );
    
    SELECT * FROM Regione;
    #Verifico tabelle
    show tables;
    
#Task3 Popola le tabelle utilizzando dati a tua discrezione 

INSERT INTO Regione (NomeRegione)
VALUES
    ('Europa'),
    ('Asia'),
    ('Stati Uniti'),
    ('Sud America'),
    ('Australia');
    
    INSERT INTO Paese (NomePaese)
VALUES
    ('Italia'),
    ('Francia'),
    ('Germania'),
    ('India'),
    ('New York'),
    ('California'),
    ('Argentina'),
    ('Nuova Zelanda');
    
    INSERT INTO Categoria (NomeCategoria)
VALUES
    ('Gioco'),
    ('Abbigliamento'),
    ('Carte'),
    ('Console');
    
    INSERT INTO Prodotti (NomeProdotto, PrezzoUnitario, ID_Categoria)
VALUES
    ('Peluche Toplino', 5, 1),
    ('Palla da calcio', 7, 1),
    ('Batman', 21, 1),
    ('Costume Superman', 37, 2),
    ('Uno', 9, 3),
    ('PlayStation', 500, 4),
    ('FIFA', 60, 1);
    
    INSERT INTO Sales (DataOrdine, NumeroOrdine, Quantita)
VALUES
    ('2024-07-03', 'A4587', 2),
    ('2024-07-03', 'A4587', 1),
    ('2024-03-17', 'A4591', 3),
    ('2023-05-20', 'A4545', 1),
    ('2024-12-31', 'A4585', 2),
    ('2023-02-01', 'A6701', 5),
    ('2023-02-01', 'A6701', 1),
    ('2023-02-01', 'A6701', 3),
    ('2024-01-26', 'A3210', 10),
    ('2023-08-05', 'A6543', 4);
    
#TASK 4
-- 1) Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per 
-- determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata).

SELECT ID_Prodotto
, COUNT(*)
FROM Prodotti
GROUP BY ID_Prodotto
HAVING COUNT(*)>1;

SELECT ID_Categoria
, COUNT(*)
FROM Categoria
GROUP BY ID_Categoria
HAVING COUNT(*)>1;

SELECT ID_Sales
, COUNT(*)
FROM Sales
GROUP BY ID_Sales
HAVING COUNT(*)>1;

SELECT ID_Paese
, COUNT(*)
FROM Paese
GROUP BY ID_Paese
HAVING COUNT(*)>1;

SELECT ID_Regione
, COUNT(*)
FROM Regione
GROUP BY ID_Regione
HAVING COUNT(*)>1;

#2) Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, 
-- il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di 
-- vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni 
-- dalla data vendita o meno (>180 -> True, <= 180 -> False)

SELECT
	NumeroOrdine
    , DataOrdine
    , NomeProdotto
    , NomeCategoria
    , NomePaese
    , NomeRegione
	, (DATEDIFF(CURDATE(),DataOrdine)>180) AS OrdineVecchio
FROM 
	sales
INNER JOIN
	prodotti AS P
ON 
	sales.ID_Prodotto=P.ID_Prodotto
INNER JOIN 
	categoria AS CAT
ON 
	CAT.ID_Categoria=P.ID_Categoria
INNER JOIN
	paese
ON 
	paese.ID_Paese=sales.ID_Paese
INNER JOIN
	regione AS REG
ON REG.ID_Regione=paese.ID_Regione;

#3) Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media 
-- delle vendite realizzate nell’ultimo anno censito. (ogni valore della condizione deve risultare da 
-- una query e non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto 
-- e il totale venduto.   

SELECT 
    ID_Prodotto
    , SUM(Quantità) AS QtàTOT
FROM 
    sales
WHERE 
    YEAR(DataOrdine)=2023
GROUP BY 
    ID_Prodotto
HAVING 
    SUM(Quantità)>(SELECT AVG(Quantità) 
					FROM sales 
					WHERE YEAR(DataOrdine)=2023)
;-- 3) Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media 
-- delle vendite realizzate nell’ultimo anno censito. (ogni valore della condizione deve risultare da 
-- una query e non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto 
-- e il totale venduto.   

SELECT 
    ID_Prodotto
    , SUM(Quantita) AS QtàTOT
FROM 
    sales
WHERE 
    YEAR(DataOrdine)=2023
GROUP BY 
    ID_Prodotto
HAVING 
    SUM(Quantita)>(SELECT AVG(Quantita) 
					FROM sales 
					WHERE YEAR(DataOrdine)=2023)
;

#4) Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 

SELECT 
    NomeProdotto
    , SUM(PrezzoUnitario*Quantita) AS FatturatoTotale
    , YEAR(DataOrdine) AS Anno
FROM 
    sales
INNER JOIN 
    prodotti AS P
ON 
    sales.ID_Prodotto=P.ID_Prodotto
GROUP BY 
    NomeProdotto 
    , YEAR(DataOrdine);
    
#5) Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
    
SELECT 
    SUM(PrezzoUnitario*Quantita) AS fatturatoTOT
    , YEAR(DataOrdine) AS Anno
    , NomePaese
FROM 
    sales
INNER JOIN 
    prodotti AS P
ON 
    Sales.ID_Prodotto=P.ID_Prodotto
INNER JOIN 
    paese 
ON 
    Sales.ID_Paese=Paese.ID_Paese
GROUP BY 
    NomePaese 
    , YEAR(DataOrdine)
ORDER BY 
    fatturatoTOT DESC;

#6) Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
#Mostro le richieste in ordine Decrescente. Soluzione semplice e veloce

SELECT
	nomecategoria
    , SUM(quantita) AS NRichieste
FROM
	Categoria AS CAT
INNER JOIN 
	Prodotti AS P
ON 
	CAT.ID_Categoria=P.ID_Categoria
INNER JOIN
	Sales
ON 
	sales.ID_prodotto=P.ID_prodotto
GROUP BY
	nomecategoria
ORDER BY NRichieste DESC;

7)	Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci 
-- risolutivi differenti. 

#Approccio con LEFT JOIN

SELECT 
	nomeprodotto
FROM
	prodotti AS P
LEFT JOIN 
	sales 
ON 
	sales.ID_prodotto=P.ID_prodotto
WHERE 
    sales.ID_Prodotto IS NULL;

#Approccio con Subquery

SELECT 
    NomeProdotto
FROM 
    Prodotti
WHERE 
    ID_Prodotto NOT IN (SELECT DISTINCT ID_Prodotto
						FROM Sales)
;

#Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle 
-- informazioni utili (codice prodotto, nome prodotto, nome categoria)

CREATE VIEW VistaProdottiDenormalizzata AS
SELECT
    p.ID_Prodotto,
    p.NomeProdotto,
    c.NomeCategoria
FROM Prodotti AS p
INNER JOIN Categoria AS c
    ON p.ID_Categoria = c.ID_Categoria;
    
#Creare una vista per le informazioni geografiche

CREATE VIEW VistaGeografica AS
SELECT
    p.ID_Paese,
    p.NomePaese,
    r.NomeRegione
FROM Paese AS p
INNER JOIN Regione AS r
    ON p.ID_Regione = r.ID_Regione;








